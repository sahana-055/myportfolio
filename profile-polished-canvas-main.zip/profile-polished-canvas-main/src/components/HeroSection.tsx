 import { motion } from "framer-motion";
 import { ArrowDown, FileText, Mail, Sparkles, Zap } from "lucide-react";
 import { Button } from "@/components/ui/button";
 
 export const HeroSection = () => {
   const scrollToSection = (id: string) => {
     const element = document.getElementById(id);
     if (element) {
       element.scrollIntoView({ behavior: "smooth" });
     }
   };
 
   return (
     <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
       {/* Animated Background */}
       <div className="absolute inset-0 gradient-hero">
         {/* Mesh gradient overlay */}
         <div className="absolute inset-0 mesh-gradient opacity-60" />
         
         {/* Animated orbs */}
         <motion.div
           className="glow-orb w-[600px] h-[600px] bg-secondary top-[-200px] left-[-200px]"
           animate={{
             scale: [1, 1.2, 1],
             x: [0, 50, 0],
             y: [0, 30, 0],
           }}
           transition={{
             duration: 10,
             repeat: Infinity,
             ease: "easeInOut",
           }}
         />
         <motion.div
           className="glow-orb w-[500px] h-[500px] bg-primary bottom-[-100px] right-[-100px]"
           animate={{
             scale: [1.2, 1, 1.2],
             x: [0, -30, 0],
             y: [0, -50, 0],
           }}
           transition={{
             duration: 8,
             repeat: Infinity,
             ease: "easeInOut",
           }}
         />
         <motion.div
           className="glow-orb w-[400px] h-[400px] bg-accent top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
           animate={{
             scale: [1, 1.3, 1],
             opacity: [0.2, 0.4, 0.2],
           }}
           transition={{
             duration: 6,
             repeat: Infinity,
             ease: "easeInOut",
           }}
         />
 
         {/* Grid pattern */}
         <div 
           className="absolute inset-0 opacity-[0.03]"
           style={{
             backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
             backgroundSize: '60px 60px',
           }}
         />
       </div>
 
       <div className="section-container relative z-10 text-center">
         {/* Badge */}
         <motion.div
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8 }}
           className="mb-8"
         >
           <motion.span 
             className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-secondary/20 backdrop-blur-xl border border-secondary/30 text-secondary-foreground text-sm font-medium"
             whileHover={{ scale: 1.05 }}
             transition={{ type: "spring", stiffness: 400 }}
           >
             <motion.span
               animate={{ rotate: [0, 360] }}
               transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
             >
               <Sparkles className="w-4 h-4 text-accent" />
             </motion.span>
             Design. Develop. Deliver.
           </motion.span>
         </motion.div>
 
         {/* Main Heading */}
         <motion.h1
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8, delay: 0.1 }}
           className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-display font-bold text-foreground mb-8 tracking-tight"
         >
           Hi, I'm{" "}
           <span className="text-gradient relative">
             Sahana!
             <motion.span
               className="absolute -right-4 -top-4"
               animate={{ rotate: [0, 20, 0] }}
               transition={{ duration: 2, repeat: Infinity }}
             >
               <Zap className="w-8 h-8 text-accent" />
             </motion.span>
           </span>
         </motion.h1>
 
         {/* Subtitle */}
         <motion.p
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8, delay: 0.2 }}
           className="text-lg md:text-xl lg:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12 leading-relaxed"
         >
           An inquisitive learner passionate about{" "}
           <span className="text-primary font-medium">technology</span>,{" "}
           <span className="text-secondary font-medium">AI</span>, and building{" "}
           <span className="text-accent font-medium">innovative solutions</span>.
         </motion.p>
 
         {/* CTA Buttons */}
         <motion.div
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           transition={{ duration: 0.8, delay: 0.3 }}
           className="flex flex-col sm:flex-row gap-4 justify-center"
         >
           <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
             <Button
               size="lg"
                className="btn-gradient text-foreground px-8 py-6 text-lg rounded-full group relative overflow-hidden min-w-[180px]"
               onClick={() => scrollToSection("contact")}
             >
               <Mail className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
               Contact Me
               <motion.span
                 className="absolute inset-0 bg-white/20"
                 initial={{ x: "-100%" }}
                 whileHover={{ x: "100%" }}
                 transition={{ duration: 0.5 }}
               />
             </Button>
           </motion.div>
           
           <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <a href="https://drive.google.com/file/d/1eOxTMCIvZ7tnRG-JWopSPtUjMNUD8r79/view?usp=sharing" target="_blank" rel="noopener noreferrer">
               <Button
                 size="lg"
                  className="btn-gradient text-foreground px-8 py-6 text-lg rounded-full group relative overflow-hidden min-w-[180px]"
               >
                 <FileText className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
                 View Resume
                  <motion.span
                    className="absolute inset-0 bg-white/20"
                    initial={{ x: "-100%" }}
                    whileHover={{ x: "100%" }}
                    transition={{ duration: 0.5 }}
                  />
               </Button>
             </a>
           </motion.div>
         </motion.div>
 
         {/* Stats row */}
         <motion.div
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
           transition={{ delay: 0.6, duration: 0.8 }}
           className="mt-16 flex flex-wrap justify-center gap-8 md:gap-16"
         >
           {[
             { label: "Projects", value: "5+" },
              { label: "Certifications", value: "15+" },
             { label: "Internships", value: "3+" },
           ].map((stat, index) => (
             <motion.div
               key={stat.label}
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.7 + index * 0.1 }}
               className="text-center"
             >
               <motion.p 
                 className="text-3xl md:text-4xl font-bold text-gradient"
                 whileHover={{ scale: 1.1 }}
               >
                 {stat.value}
               </motion.p>
               <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
             </motion.div>
           ))}
         </motion.div>
 
         {/* Scroll Indicator */}
         <motion.div
           initial={{ opacity: 0 }}
           animate={{ opacity: 1 }}
           transition={{ delay: 1.2, duration: 0.8 }}
           className="absolute bottom-8 left-1/2 -translate-x-1/2"
         >
           <motion.button
             onClick={() => scrollToSection("about")}
             className="flex flex-col items-center gap-2 text-muted-foreground hover:text-primary transition-colors group"
             animate={{ y: [0, 10, 0] }}
             transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
           >
             <span className="text-xs font-medium uppercase tracking-widest">Scroll</span>
             <div className="w-6 h-10 rounded-full border-2 border-current flex items-start justify-center p-2">
               <motion.div
                 className="w-1.5 h-1.5 rounded-full bg-current"
                 animate={{ y: [0, 12, 0] }}
                 transition={{ duration: 1.5, repeat: Infinity }}
               />
             </div>
           </motion.button>
         </motion.div>
       </div>
     </section>
   );
 };