import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Award, ExternalLink, CheckCircle2 } from "lucide-react";

const certifications = [
  {
    title: "Human Computer Interaction",
    platform: "NPTEL",
    score: "82%",
    icon: "🎓",
    gradient: "from-blue-500 to-indigo-500",
  },
  {
    title: "Generative AI Fundamentals",
    platform: "Databricks",
    date: "August 2025",
    icon: "🤖",
    gradient: "from-violet-500 to-purple-500",
  },
  {
    title: "Introduction to Generative AI Concepts",
    platform: "Microsoft",
    date: "June 2025",
    icon: "💡",
    gradient: "from-cyan-500 to-blue-500",
  },
  {
    title: "Python for Placement Readiness",
    platform: "ByteXL",
    date: "August 2025",
    icon: "🐍",
    gradient: "from-yellow-500 to-orange-500",
  },
  {
    title: "Basic Data Structures and Algorithms",
    platform: "ByteXL",
    date: "September 2025",
    icon: "📊",
    gradient: "from-green-500 to-emerald-500",
  },
  {
    title: "Agentforce Specialist",
    platform: "Salesforce",
    date: "December 2025",
    icon: "☁️",
    gradient: "from-blue-400 to-cyan-400",
  },
  {
    title: "Foundations Associate",
    platform: "Oracle",
    date: "January 2026",
    icon: "🔴",
    gradient: "from-red-500 to-orange-500",
  },
  {
    title: "Analytics Vidhya Course",
    platform: "Analytics Vidhya",
    date: "January 2026",
    icon: "📈",
    gradient: "from-indigo-500 to-blue-500",
  },
];

export const CertificationsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="certifications" className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent/10 rounded-full blur-[150px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-primary/10 rounded-full blur-[120px]" />
      </div>
      
      <div className="section-container relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.span 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/30 text-accent text-sm font-semibold uppercase tracking-wider mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2 }}
          >
            <Award className="w-4 h-4" />
            Certifications
          </motion.span>
          <h2 className="section-title mt-4">
            Professional <span className="text-gradient">Credentials</span>
          </h2>
          <p className="section-subtitle mx-auto mt-4">
            Continuous learning through industry-recognized certifications
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {certifications.map((cert, index) => (
            <motion.div
              key={cert.title}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={isInView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.1 + index * 0.05 }}
              whileHover={{ y: -8, scale: 1.03 }}
              className="glass-card rounded-2xl p-6 group cursor-pointer card-shine neon-border relative overflow-hidden"
            >
              {/* Top gradient line */}
              <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${cert.gradient} opacity-0 group-hover:opacity-100 transition-opacity`} />
              
              <div className="flex items-start gap-4">
                <motion.span 
                  className="text-3xl"
                  whileHover={{ scale: 1.2, rotate: [0, -10, 10, 0] }}
                  transition={{ duration: 0.4 }}
                >
                  {cert.icon}
                </motion.span>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold text-foreground text-sm leading-tight mb-2 group-hover:text-gradient transition-all line-clamp-2">
                    {cert.title}
                  </h3>
                  <p className={`text-transparent bg-clip-text bg-gradient-to-r ${cert.gradient} text-xs font-bold mb-3`}>
                    {cert.platform}
                  </p>
                  <div className="flex items-center gap-2 flex-wrap">
                    {cert.score && (
                      <motion.span 
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-green-500/20 text-green-400 text-xs font-bold border border-green-500/30"
                        whileHover={{ scale: 1.05 }}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {cert.score}
                      </motion.span>
                    )}
                    {cert.date && (
                      <span className="text-muted-foreground text-xs font-medium">{cert.date}</span>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
