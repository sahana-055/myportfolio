import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Brain, Users, Lightbulb, Zap, ArrowRight } from "lucide-react";

const highlights = [
  {
    icon: Brain,
    title: "Problem Solver",
    description: "Strong analytical mindset for tackling complex technical challenges",
    gradient: "from-purple-500 to-pink-500",
  },
  {
    icon: Lightbulb,
    title: "AI Enthusiast",
    description: "Deep interest in artificial intelligence and its real-world applications",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    icon: Zap,
    title: "Quick Learner",
    description: "Rapidly adapting to new technologies and frameworks",
    gradient: "from-orange-500 to-yellow-500",
  },
  {
    icon: Users,
    title: "Team Player",
    description: "Excellent collaboration and mentoring abilities",
    gradient: "from-green-500 to-emerald-500",
  },
];

export const AboutSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-20 md:py-32 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 mesh-gradient opacity-30" />
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px]" />
      
      <div className="section-container relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.span 
            className="inline-block px-4 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary text-sm font-semibold uppercase tracking-wider mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2 }}
          >
            About Me
          </motion.span>
          <h2 className="section-title mt-4">
            Passionate About{" "}
            <span className="text-gradient">Technology</span>
          </h2>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* About Text */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="glass-card rounded-3xl p-8 md:p-10 card-shine neon-border">
              <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                I am a motivated Computer Science and Engineering student with a strong interest in 
                technology and problem-solving. I possess solid skills in{" "}
                <span className="text-primary font-medium">Python</span>,{" "}
                <span className="text-secondary font-medium">Java</span>,{" "}
                <span className="text-accent font-medium">C</span>, and web 
                development, along with hands-on knowledge of AI concepts and vibe coding.
              </p>
              <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                As a quick learner with excellent teamwork and mentoring abilities, I am always eager 
                to explore new technologies. My goal is to continuously improve my technical skills 
                and contribute effectively to innovative and impactful solutions.
              </p>
              
              <div className="flex flex-wrap gap-3">
                {["Python", "AI/ML", "Web Dev", "Problem Solving", "Leadership"].map(
                  (skill, index) => (
                    <motion.span
                      key={skill}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={isInView ? { opacity: 1, scale: 1 } : {}}
                      transition={{ delay: 0.4 + index * 0.1 }}
                      whileHover={{ scale: 1.05, y: -2 }}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-primary/20 to-secondary/20 border border-primary/30 text-foreground text-sm font-medium cursor-default"
                    >
                      {skill}
                    </motion.span>
                  )
                )}
              </div>
            </div>
          </motion.div>

          {/* Highlights Grid */}
          <div className="grid sm:grid-cols-2 gap-4">
            {highlights.map((item, index) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                className="glass-card rounded-2xl p-6 group cursor-default card-shine"
              >
                <motion.div 
                  className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center mb-4 shadow-lg`}
                  whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                >
                  <item.icon className="w-7 h-7 text-white" />
                </motion.div>
                <h3 className="font-bold text-foreground mb-2 text-lg group-hover:text-gradient transition-all">
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {item.description}
                </p>
                <motion.div
                  className="mt-4 flex items-center gap-1 text-primary text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity"
                  initial={{ x: -10 }}
                  whileHover={{ x: 0 }}
                >
                  Learn more <ArrowRight className="w-4 h-4" />
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
