import { motion } from "framer-motion";
import { Heart, Linkedin, Mail, Phone, Sparkles, ArrowUp } from "lucide-react";

export const Footer = () => {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer className="relative py-12 border-t border-border/30 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          {/* Logo & Copyright */}
          <div className="flex flex-col items-center md:items-start gap-3">
            <motion.div 
              className="flex items-center gap-2"
              whileHover={{ scale: 1.05 }}
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary via-secondary to-accent flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-background" />
              </div>
              <span className="font-display text-2xl font-bold text-gradient">
                Sahana C
              </span>
            </motion.div>
          </div>

          {/* Social Links */}
          <div className="flex items-center gap-3">
            {[
              { icon: Mail, href: "mailto:sahanac055@gmail.com", gradient: "from-blue-500 to-cyan-500" },
              { icon: Phone, href: "tel:+919003840717", gradient: "from-green-500 to-emerald-500" },
              { icon: Linkedin, href: "https://www.linkedin.com/in/sahanacholeeswaran/", gradient: "from-blue-600 to-indigo-600" },
            ].map((item, index) => (
              <motion.a
                key={index}
                href={item.href}
                target={item.icon === Linkedin ? "_blank" : undefined}
                rel={item.icon === Linkedin ? "noopener noreferrer" : undefined}
                whileHover={{ y: -4, scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.gradient} flex items-center justify-center shadow-lg hover:shadow-xl transition-shadow`}
              >
                <item.icon className="w-5 h-5 text-white" />
              </motion.a>
            ))}
          </div>

          {/* Made with + Back to top */}
          <div className="flex items-center gap-6">
            <p className="text-sm text-muted-foreground flex items-center gap-1.5">
              Made with{" "}
              <motion.span
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <Heart className="w-4 h-4 text-pink-500 fill-pink-500" />
              </motion.span>{" "}
              by Sahana
            </p>
            
            <motion.button
              onClick={scrollToTop}
              whileHover={{ y: -4, scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="w-10 h-10 rounded-xl glass-card flex items-center justify-center border border-border/50 hover:border-primary/50 transition-colors"
            >
              <ArrowUp className="w-4 h-4 text-muted-foreground" />
            </motion.button>
          </div>
        </div>
      </div>
    </footer>
  );
};
