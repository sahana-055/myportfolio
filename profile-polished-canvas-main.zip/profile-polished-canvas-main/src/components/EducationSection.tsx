import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { GraduationCap, Calendar, Award, MapPin } from "lucide-react";

const education = [
  {
    degree: "B.E. Computer Science and Engineering",
    institution: "SNS College of Technology, Coimbatore",
    percentage: "89%",
    year: "Expected 2027",
    current: true,
  },
  {
    degree: "Higher Secondary (12th)",
    institution: "Chandra Matriculation Higher Secondary School, Coimbatore",
    percentage: "82%",
    year: "2023",
    current: false,
  },
  {
    degree: "Secondary (10th)",
    institution: "Chandra Matriculation Higher Secondary School, Coimbatore",
    percentage: "80%",
    year: "2020",
    current: false,
  },
];

export const EducationSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="education" className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 mesh-gradient opacity-20" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent/10 rounded-full blur-[120px]" />
      
      <div className="section-container relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.span 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/30 text-accent text-sm font-semibold uppercase tracking-wider mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2 }}
          >
            <GraduationCap className="w-4 h-4" />
            Education
          </motion.span>
          <h2 className="section-title mt-4">
            Academic <span className="text-gradient">Journey</span>
          </h2>
        </motion.div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-8 md:left-12 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-secondary to-accent hidden md:block" />

            {education.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -40 }}
                animate={isInView ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.15 }}
                className="relative mb-8 last:mb-0"
              >
                <div className="flex gap-6 md:gap-8 items-start">
                  {/* Timeline Dot */}
                  <motion.div 
                    className="hidden md:flex"
                    whileHover={{ scale: 1.1 }}
                  >
                    <div className={`w-16 h-16 md:w-20 md:h-20 rounded-2xl flex items-center justify-center z-10 ${
                      item.current 
                        ? "bg-gradient-to-br from-primary via-secondary to-accent shadow-glow" 
                        : "glass-card border border-border/50"
                    }`}>
                      <GraduationCap className={`w-8 h-8 ${item.current ? "text-white" : "text-primary"}`} />
                    </div>
                  </motion.div>

                  {/* Content Card */}
                  <motion.div 
                    className={`flex-1 glass-card rounded-3xl p-6 md:p-8 card-shine ${
                      item.current ? "neon-border" : ""
                    }`}
                    whileHover={{ y: -4, scale: 1.01 }}
                    transition={{ duration: 0.3 }}
                  >
                    {item.current && (
                      <motion.span 
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-primary/20 to-secondary/20 border border-primary/30 text-primary text-xs font-bold mb-4"
                        animate={{ opacity: [1, 0.7, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                        Currently Pursuing
                      </motion.span>
                    )}
                    <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2">{item.degree}</h3>
                    <p className="text-muted-foreground mb-6 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-secondary" />
                      {item.institution}
                    </p>
                    <div className="flex flex-wrap gap-4">
                      <motion.div 
                        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30"
                        whileHover={{ scale: 1.05 }}
                      >
                        <Award className="w-5 h-5 text-green-400" />
                        <span className="text-green-400 font-bold">{item.percentage}</span>
                      </motion.div>
                      <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-muted/50 border border-border/50">
                        <Calendar className="w-5 h-5 text-muted-foreground" />
                        <span className="text-muted-foreground font-medium">{item.year}</span>
                      </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
