import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Briefcase, MapPin, Calendar, Globe, Building, ArrowUpRight, ExternalLink } from "lucide-react";

const experiences = [
  {
    role: "Data Science Intern",
    company: "Elite Tech Intern",
    location: "Coimbatore",
    duration: "Mar 28 - April 28, 2025",
    mode: "Online",
    description: "Gained hands-on experience in data science methodologies, machine learning algorithms, and data analysis techniques.",
    highlights: ["Data Analysis", "Machine Learning", "Python"],
    gradient: "from-blue-500 to-cyan-500",
    link: "https://www.linkedin.com/company/elite-tech-intern/posts/?feedView=all",
  },
  {
    role: "AWS Intern",
    company: "Techsnapie Solutions",
    location: "Coimbatore",
    duration: "Aug 1 - Aug 15, 2024",
    mode: "Offline",
    description: "Developed practical knowledge of Amazon Web Services, cloud infrastructure, and deployment strategies.",
    highlights: ["AWS", "Cloud Computing", "Infrastructure"],
    gradient: "from-orange-500 to-amber-500",
    link: "https://www.justdial.com/Coimbatore/Techsnapie-Solutions-SNS-College-Of-Engineering-Saravanampatti/0422PX422-X422-230614040713-I3C6_BZDET",
  },
];

export const ExperienceSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="experience" className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[150px] -translate-y-1/2" />
        <div className="absolute top-1/2 right-0 w-[400px] h-[400px] bg-secondary/10 rounded-full blur-[120px] -translate-y-1/2" />
      </div>
      
      <div className="section-container relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.span 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary text-sm font-semibold uppercase tracking-wider mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2 }}
          >
            <Briefcase className="w-4 h-4" />
            Experience
          </motion.span>
          <h2 className="section-title mt-4">
            Professional <span className="text-gradient">Experience</span>
          </h2>
          <p className="section-subtitle mx-auto mt-4">
            Internships and hands-on learning experiences
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.15 }}
              whileHover={{ y: -12 }}
              className="glass-card rounded-3xl p-8 group card-shine neon-border relative overflow-hidden cursor-pointer"
              onClick={() => window.open(exp.link, "_blank", "noopener,noreferrer")}
            >
              {/* Gradient accent */}
              <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${exp.gradient}`} />
              
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <motion.div 
                  className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${exp.gradient} flex items-center justify-center shadow-xl`}
                  whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                >
                  <Briefcase className="w-8 h-8 text-white" />
                </motion.div>
                <motion.span 
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold ${
                    exp.mode === "Online" 
                      ? "bg-blue-500/20 text-blue-400 border border-blue-500/30" 
                      : "bg-green-500/20 text-green-400 border border-green-500/30"
                  }`}
                  whileHover={{ scale: 1.05 }}
                >
                  {exp.mode === "Online" ? <Globe className="w-3.5 h-3.5" /> : <Building className="w-3.5 h-3.5" />}
                  {exp.mode}
                </motion.span>
              </div>

              {/* Content */}
              <h3 className="text-2xl font-bold text-foreground mb-1 group-hover:text-gradient transition-all">{exp.role}</h3>
              <p className="text-primary font-semibold text-lg mb-4">{exp.company}</p>
              
              <div className="flex flex-wrap gap-4 mb-5 text-sm text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-secondary" />
                  {exp.location}
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-accent" />
                  {exp.duration}
                </div>
              </div>

              <p className="text-muted-foreground mb-6 leading-relaxed">{exp.description}</p>

              {/* Skills */}
              <div className="flex flex-wrap gap-2 mb-4">
                {exp.highlights.map((skill) => (
                  <motion.span
                    key={skill}
                    whileHover={{ scale: 1.05 }}
                    className={`px-4 py-2 rounded-xl bg-gradient-to-r ${exp.gradient} text-white text-xs font-semibold shadow-lg`}
                  >
                    {skill}
                  </motion.span>
                ))}
              </div>

              {/* Hover indicator */}
              <motion.div 
                className="absolute bottom-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity"
                whileHover={{ scale: 1.1 }}
              >
                <ExternalLink className="w-5 h-5 text-primary" />
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
