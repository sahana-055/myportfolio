import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Film, Pill, Users, ExternalLink, Sparkles, ArrowUpRight, Star, Package } from "lucide-react";

const projects = [
  {
    title: "Smart Movie Recommender",
    description: "An intelligent movie recommendation system that analyzes user preferences and viewing patterns to suggest personalized movie choices using machine learning algorithms.",
    icon: Film,
    tags: ["Python", "Machine Learning", "Streamlit"],
    gradient: "from-orange-500 via-rose-500 to-pink-500",
    featured: true,
    link: "https://github.com/sahana-055/movie-recommender-website",
  },
  {
    title: "Smart Parcel Delay Prediction",
    description: "A machine learning model designed to predict delivery delays for small parcels, helping logistics companies optimize their operations and improve customer satisfaction.",
    icon: Package,
    tags: ["AI/ML", "Python", "Prediction"],
    gradient: "from-emerald-500 via-teal-500 to-cyan-500",
    featured: false,
    link: "https://github.com/sahana-055/Smart-Parcel-Delay-Prediction",
  },
  {
    title: "SmartMeet",
    description: "An intelligent virtual assistant that summarizes meetings, tracks tasks, and enhances team productivity through advanced speech recognition and NLP.",
    icon: Users,
    tags: ["AI", "Speech Recognition", "NLP"],
    gradient: "from-violet-500 via-purple-500 to-fuchsia-500",
    featured: false,
    link: "https://github.com/sahana-055/SmartMeet",
  },
];

export const ProjectsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="projects" className="py-20 md:py-32 relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute inset-0 mesh-gradient opacity-30" />
      <motion.div 
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full"
        style={{
          background: "radial-gradient(circle, hsl(270 70% 30% / 0.2) 0%, transparent 70%)",
        }}
        animate={{ scale: [1, 1.1, 1], opacity: [0.3, 0.5, 0.3] }}
        transition={{ duration: 8, repeat: Infinity }}
      />
      
      <div className="section-container relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.span 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/30 text-secondary text-sm font-semibold uppercase tracking-wider mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2 }}
          >
            <Sparkles className="w-4 h-4" />
            Projects
          </motion.span>
          <h2 className="section-title mt-4">
            Featured <span className="text-gradient">Work</span>
          </h2>
          <p className="section-subtitle mx-auto mt-4">
            Innovative solutions leveraging AI and machine learning
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {projects.map((project, index) => (
            <motion.a
              href={project.link}
              target="_blank"
              rel="noopener noreferrer"
              key={project.title}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
              whileHover={{ y: -12, scale: 1.02 }}
              className="group relative cursor-pointer"
            >
              <div className="glass-card rounded-3xl p-8 h-full flex flex-col card-shine neon-border relative overflow-hidden">
                {/* Featured badge */}
                {project.featured && (
                  <motion.div 
                    className="absolute top-4 right-4 flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-white text-xs font-bold"
                    animate={{ rotate: [0, 5, -5, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    <Star className="w-3 h-3 fill-current" />
                    Featured
                  </motion.div>
                )}

                {/* Icon */}
                <motion.div 
                  className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${project.gradient} flex items-center justify-center mb-6 shadow-xl`}
                  whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                  transition={{ duration: 0.5 }}
                >
                  <project.icon className="w-8 h-8 text-white" />
                </motion.div>

                {/* Content */}
                <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-gradient transition-all">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-grow">
                  {project.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag) => (
                    <motion.span
                      key={tag}
                      whileHover={{ scale: 1.05 }}
                      className={`px-3 py-1.5 rounded-lg bg-gradient-to-r ${project.gradient} text-white text-xs font-semibold shadow-md`}
                    >
                      {tag}
                    </motion.span>
                  ))}
                </div>

                {/* Action */}
                <motion.a
                  href={project.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ x: 8 }}
                  className="flex items-center gap-2 text-primary text-sm font-semibold group/btn"
                >
                  <Sparkles className="w-4 h-4 group-hover/btn:rotate-12 transition-transform" />
                  View Project
                  <ArrowUpRight className="w-4 h-4 opacity-0 group-hover/btn:opacity-100 transition-all" />
                </motion.a>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
};
