import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { Trophy, Medal, Users, Code, Lightbulb, Star, Zap, Calendar } from "lucide-react";

const achievements = [
  {
    icon: Trophy,
    title: "1st Prize - Technical Quiz",
    event: "Fiestaa'25",
    venue: "KPR Institute of Engineering and Technology",
    type: "winner",
    gradient: "from-amber-400 via-yellow-400 to-orange-400",
  },
  {
    icon: Users,
    title: "LeetCode Mentor",
    event: "15 Days Training Program",
    venue: "Dr.SNS Rajalakshmi College of Arts and Science",
    type: "mentor",
    gradient: "from-emerald-400 via-green-400 to-teal-400",
  },
  {
    icon: Lightbulb,
    title: "WWT Women-Only Hackathon 2025",
    event: "AI for Financial Inclusion of Women",
    venue: "All India Hackathon",
    type: "participant",
    gradient: "from-pink-400 via-rose-400 to-red-400",
  },
  {
    icon: Code,
    title: "Code O Clock 2025",
    event: "24 Hours Hackathon - SmartMeet",
    venue: "Coimbatore Institute of Technology",
    type: "participant",
    gradient: "from-violet-400 via-purple-400 to-fuchsia-400",
  },
  {
    icon: Calendar,
    title: "Tech Event Participation",
    event: "Technical Symposium",
    venue: "NGP College",
    type: "participant",
    gradient: "from-cyan-400 via-sky-400 to-blue-400",
  },
  {
    icon: Calendar,
    title: "Tech Event Participation",
    event: "Technical Symposium",
    venue: "PSG College",
    type: "participant",
    gradient: "from-orange-400 via-amber-400 to-yellow-400",
  },
];

export const AchievementsSection = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const getTypeBadge = (type: string) => {
    switch (type) {
      case "winner":
        return { text: "1st Place", icon: Trophy, gradient: "from-amber-500 to-orange-500" };
      case "runner":
        return { text: "3rd Place", icon: Medal, gradient: "from-slate-400 to-gray-500" };
      case "mentor":
        return { text: "Mentor", icon: Star, gradient: "from-emerald-500 to-teal-500" };
      default:
        return { text: "Participant", icon: Zap, gradient: "from-violet-500 to-purple-500" };
    }
  };

  return (
    <section id="achievements" className="py-20 md:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 mesh-gradient opacity-20" />
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[150px] -translate-y-1/2" />
      
      <div className="section-container relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.span 
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/30 text-secondary text-sm font-semibold uppercase tracking-wider mb-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ delay: 0.2 }}
          >
            <Trophy className="w-4 h-4" />
            Achievements
          </motion.span>
          <h2 className="section-title mt-4">
            Awards & <span className="text-gradient">Activities</span>
          </h2>
          <p className="section-subtitle mx-auto mt-4">
            Recognitions, hackathons, and community contributions
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {achievements.map((item, index) => {
            const badge = getTypeBadge(item.type);
            const BadgeIcon = badge.icon;
            
            return (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="glass-card rounded-3xl p-6 group card-shine neon-border relative overflow-hidden"
              >
                {/* Top gradient accent */}
                <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${item.gradient}`} />
                
                <div className="flex items-start gap-4">
                  <motion.div 
                    className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${item.gradient} flex items-center justify-center flex-shrink-0 shadow-xl`}
                    whileHover={{ rotate: [0, -10, 10, 0], scale: 1.1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <item.icon className="w-7 h-7 text-white" />
                  </motion.div>
                  <div className="flex-1 min-w-0">
                    <motion.span 
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r ${badge.gradient} text-white text-xs font-bold mb-3 shadow-lg`}
                      whileHover={{ scale: 1.05 }}
                    >
                      <BadgeIcon className="w-3.5 h-3.5" />
                      {badge.text}
                    </motion.span>
                    <h3 className="font-bold text-foreground mb-2 leading-tight group-hover:text-gradient transition-all">
                      {item.title}
                    </h3>
                    <p className="text-sm text-primary font-medium mb-1">{item.event}</p>
                    <p className="text-xs text-muted-foreground">{item.venue}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
